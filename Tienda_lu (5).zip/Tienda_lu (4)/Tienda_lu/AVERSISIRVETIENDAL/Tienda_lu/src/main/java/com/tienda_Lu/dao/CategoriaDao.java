
package com.tienda_Lu.dao;

import com.tienda_Lu.domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CategoriaDao extends JpaRepository <Categoria, Long> {

   
    
}